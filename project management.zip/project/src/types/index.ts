export interface User {
  id: string;
  email: string;
  full_name: string;
  avatar_url?: string;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  status: 'active' | 'completed' | 'on_hold';
  created_at: string;
  owner_id: string;
}

export interface Task {
  id: string;
  project_id: string;
  title: string;
  description: string;
  status: 'todo' | 'in_progress' | 'completed';
  assigned_to: string;
  due_date: string;
  priority: 'low' | 'medium' | 'high';
  created_at: string;
}