import React from 'react';

const Projects: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-900">Projects</h1>
        <button className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">
          New Project
        </button>
      </div>
      
      <div className="bg-white shadow rounded-lg">
        <div className="p-6">
          <p className="text-gray-500 text-center">No projects found</p>
        </div>
      </div>
    </div>
  );
};

export default Projects;